# Draft: NEW INC (New Museum)
**Target:** New Museum / NEW INC
**Track:** program
**Status:** qualified
**Generated:** 2026-02-23

---

## Application Form

*[MISSING — needs manual content for: application_form]*

## Project Description

# Project: The ORGANVM Eight-Organ System

## One-Line
101-repository creative system coordinated across 8 GitHub organizations through automated governance.

## Short (100 words)
The ORGANVM system coordinates 101 repositories across 8 GitHub organizations — spanning theory, generative art, commercial products, governance, public process, community, and marketing. A machine-readable registry serves as single source of truth. Automated dependency validation enforces architectural rules (no circular dependencies, no back-edges). A formal promotion state machine governs how work moves between organs. 82+ CI/CD pipelines, 2,349+ tests, 33 development sprints, and ~404K+ words of documentation — all built by a single practitioner using AI tools as compositional instruments.

## Full
The eight-organ system coordinates:

- **ORGAN-I (Theoria):** 20 repos — epistemology, recursion, ontology
- **ORGAN-II (Poiesis):** 30 repos — generative art, performance, experiential systems
- **ORGAN-III (Ergon):** 27 repos — SaaS products, B2B/B2C tools
- **ORGAN-IV (Taxis):** 7 repos — orchestration, governance, AI agents
- **ORGAN-V (Logos):** 2 repos — public process essays, building in public
- **ORGAN-VI (Koinonia):** 4 repos — community infrastructure, salons
- **ORGAN-VII (Kerygma):** 4 repos — POSSE distribution, marketing
- **META-ORGANVM:** 7 repos — cross-system governance, registry, dashboard

Key infrastructure: `registry-v2.json` as single source of truth, `governance-rules.json` encoding constitutional principles, automated dependency validation (31 edges, 0 violations), promotion state machine (LOCAL → CANDIDATE → PUBLIC_PROCESS → GRADUATED → ARCHIVED), 5 GitHub Actions workflows for autonomous governance.

## Links
- Portfolio: https://4444j99.github.io/portfolio/
- System Hub: https://github.com/meta-organvm
- Public Process: https://organvm-v-logos.github.io/public-process/
- Central Registry: https://github.com/meta-organvm/organvm-corpvs-testamentvm

*[226 words, 1913 chars — source: block:projects/organvm-system]*

## Portfolio

https://4444j99.github.io/portfolio/

*[1 words, 36 chars — source: profile]*
